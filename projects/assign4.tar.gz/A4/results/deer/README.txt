code to runn :)

python viscomp.py --source ../test_images/deer/source.png --target ../test_images/deer/target.png --init-nnf ../results/deer/deer.init.npy -iters 5 --partial-results --nnf-image --nnf-vectors --rec-source --output ../test_images/deer/deer
