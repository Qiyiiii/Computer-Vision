code to run :)

python viscomp.py --source ../test_images/jaguar/source.png --target ../test_images/jaguar/target.png --init-nnf ../results/jaguar/jaguar.init.npy -iters 5 --partial-results --nnf-image --nnf-vectors --rec-source --output ../test_images/jaguar/jaguar 
