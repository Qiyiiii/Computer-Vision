code to run :)

python viscomp.py --source ../test_images/cho/source.png --target ../test_images/cho/target.png --init-nnf ../results/cho/cho.init.npy -iters 5 --partial-results --nnf-image --nnf-vectors --rec-source --output ../test_images/cho/cho
