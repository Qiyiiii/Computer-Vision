code to run :)

python viscomp.py --source ../test_images/canyon/source.jpg --target ../test_images/canyon/target.jpg --init-nnf ../results/canyon/canyon.init.npy -iters 5 --partial-results --nnf-image --nnf-vectors --rec-source --output ../test_images/canyon/canyon



I compressed all images because they are too large to hand in
