code to run :)

python viscomp.py --source ../test_images/cat/source.png --target ../test_images/cat/target.png --init-nnf ../results/cat/cat.init.npy -iters 5 --partial-results --nnf-image --nnf-vectors --rec-
source --output ../test_images/cat/cat


I compressed pictures because Markus won't accept my submission with 83mb