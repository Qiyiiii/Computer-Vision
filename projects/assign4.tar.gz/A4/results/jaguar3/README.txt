
Code to run :)

python viscomp.py --source ../test_images/jaguar3/source.png --target ../test_images/jaguar3/target.png --init-nnf ../results/jaguar3/jaguar.init.npy -iters 5 --partial-results --nnf-image --nnf-vectors --rec-source --output ../test_images/jaguar3/jaguar3
